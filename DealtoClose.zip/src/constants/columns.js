
export let datatableData = [
    {
        dataField: 'id',
        text: '#'
    }, {
        dataField: 'title',
        text: 'Department'
        // }, {
        //     dataField: 'code',
        //     text: 'Code'
        // }, {
        //     dataField: 'actions',
        //     text: "",
        //     isDummyField: true,
        //     formatter: (cell, row) => <>
        //         <Link to="#" className="btn btn-outline-secondary btn-sm edit" onClick={() => handleEdit(row.id)} title="Edit" ><i className={`fas fa-pencil-alt`} /></Link>
        //         {" "}
        //         <Link to="#" className={`btn btn-${row.status == 0 ? "danger" : "success"} btn-sm edit`} onClick={() => handleRemove(row.id, row.status == 1 ? 0 : 1, row.code)} title={row.status == 0 ? 'delete' : 'restore'} ><i className={`fas fas fa-trash-alt`} /></Link>
        //     </>
    }
];
