export const REPORTS = "/reports"

// login
export const LOGIN_URL = "/login"

// Events
export const EVENTS_URL = "/event"
export const VISITOR_API = "/visitormanagement"