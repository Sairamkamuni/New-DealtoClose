export const preDealTabs = [
    { id: 1, label: "All" },
    { id: 2, label: "Buyer / Tenant" },
    { id: 3, label: "Seller / Landlord" },
]