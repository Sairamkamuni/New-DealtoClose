import React, { useState } from "react";

const EmailTab = () => {


    return (
        <p className="text-center text-muted">No Emails Here Right Now</p>
    );
};

export default EmailTab;
