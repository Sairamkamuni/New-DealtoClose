import React, { useState } from "react";

const NotesTab = () => {


    return (
        <p className="text-center text-muted">No Notes Here Right Now</p>
    );
};

export default NotesTab;
