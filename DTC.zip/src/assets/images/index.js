import avatar1 from "./users/avatar-1.jpg"

export default { avatar1 }
